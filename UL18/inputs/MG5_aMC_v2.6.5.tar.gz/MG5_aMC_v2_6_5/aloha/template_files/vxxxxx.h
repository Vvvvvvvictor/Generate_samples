#ifndef v_guard
#define v_guard
#include <complex>
void vxxxxx(double p[4],double vmass, int nhel,int nsv, std::complex<double> v[6]);
#endif
